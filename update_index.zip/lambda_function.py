import boto3
import json

#Setting the bucket name and file name
s3_bucket = 'my-unique-bucket-name-demo'
s3_key = 'index.html'

def lambda_handler(event, context):
    # Getting string value from event and setting 'dynamic string' as default value
    dynamic_string = event.get('dynamicString', 'dynamic string')

    # Update the Original string with updated input sub-string 
    html_content = f'<h1>The saved string is {dynamic_string}</h1>'
    
    #initialize s3 connection and push updated html content to s3
    s3 = boto3.client('s3')
    try:
        s3.put_object(
            Bucket=s3_bucket,
            Key=s3_key,
            Body=html_content,
            ContentType='text/html',
            ACL='public-read'
        )
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: Unable to upload updated HTML content to S3. {str(e)}')
        }

    return {
        'statusCode': 200,
        'body': json.dumps('dynamicString updated successfully')
    }
